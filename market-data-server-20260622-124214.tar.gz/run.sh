#!/bin/bash
DB_HOST=${DB_HOST:-localhost}
DB_PORT=${DB_PORT:-5432}
DB_NAME=${DB_NAME:-trade_collector}
DB_USER=${DB_USER:-trade_user}
DB_PASSWORD=${DB_PASSWORD:-dev_password}
HTTP_HOST=${HTTP_HOST:-0.0.0.0}
HTTP_PORT=${HTTP_PORT:-8085}
cd /opt/market-data-server/current
exec java -Xmx512m -jar market-data-server.jar
